# -*- coding: utf-8 -*-
"""
三个模型（ours / tangram / spage）跨时间点：
- 箱型图（Spot-wise / Gene-wise 余弦相似度，三模型并列）
- 小提琴图（同上）
- 差异热图（Pred - True，像表达矩阵那样展示；抽取高方差基因与部分 spot）

统一评估口径：
    pred_raw = M^T @ A_raw → clip>=0 → normalize_total(1e4)+log1p → 与 B 对齐
"""

import os
import numpy as np
import torch
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from sklearn.metrics import r2_score, mean_squared_error

# ========= 基本配置 =========
BASE_DIR   = r"E:\code\deeptalk\selected_HVG2000"
TIMEPOINTS = ["0h", "12h", "24h"]
TARGET_SUM = 1e4

# 三模型（名称 → 三件套文件后缀）
MODELS = {
    "PSTN":    "",          # 无后缀：A_raw_{tp}.npy / B_{tp}.npy / mapping_matrix_{tp}.pt
    "Tangram": "_tangram",
    "SpaGE":   "_spage",
}

# 画图风格
sns.set(style="whitegrid", context="talk")
PALETTE       = "Set2"
FIGSIZE_BOX   = (8, 5)
FIGSIZE_VLN   = (8, 5)

# 差异热图可视化控制
DIFF_GENE_TOPVARS = 60    # 选基因数（按 true 的列方差排序取前 N）
DIFF_MAX_SPOTS    = 500   # 最多展示多少个 spot（超出则等间隔抽样）
DIFF_CMAP         = "vlag"  # 对称色图，中心 0
DIFF_CENTER       = 0.0
DIFF_FIGSIZE      = (10, 6)
DIFF_DPI          = 180

# ========= 小工具 =========
def normalize_log1p_np(mat, target_sum=1e4):
    """per-spot normalize_total + log1p"""
    mat = np.asarray(mat, dtype=np.float32)
    sums = mat.sum(axis=1, keepdims=True)
    sums[sums == 0] = 1.0
    normed = (mat / sums) * target_sum
    return np.log1p(normed)

def _candidates(prefix, tp, suffix, ext):
    cands = []
    cands.append(f"{prefix}_{tp}{suffix}{ext}")
    if not str(tp).endswith("h"):
        cands.append(f"{prefix}_{tp}h{suffix}{ext}")
    if str(tp).endswith("h"):
        try:
            ti = int(str(tp)[:-1])
            cands.append(f"{prefix}_{ti}h{suffix}{ext}")
        except:
            pass
    return cands

def find_file(base_dir, prefix, tp, suffix, ext):
    for name in _candidates(prefix, tp, suffix, ext):
        path = os.path.join(base_dir, name)
        if os.path.exists(path):
            return path
    return None

def safe_corr(x, y):
    if np.std(x) <= 1e-12 or np.std(y) <= 1e-12:
        return np.nan
    return np.corrcoef(x, y)[0, 1]

def cosine_vectors(A, B, axis=1, eps=1e-8):
    """按行/按列计算余弦相似度（向量一一对应）"""
    import torch.nn.functional as F
    A = torch.tensor(A, dtype=torch.float32)
    B = torch.tensor(B, dtype=torch.float32)
    if axis == 1:
        Pa = F.normalize(A + eps, dim=1)
        Pb = F.normalize(B + eps, dim=1)
        sims = (Pa * Pb).sum(dim=1).cpu().numpy()
    else:
        Pa = F.normalize(A.T + eps, dim=1)
        Pb = F.normalize(B.T + eps, dim=1)
        sims = (Pa * Pb).sum(dim=1).cpu().numpy()
    return sims

def load_and_predict_for_model(tp, model_name, suffix):
    """读取 A_raw / B / M，做统一口径预测，返回：
       dict(row_sims, col_sims, metrics, pred, true) 或 None
    """
    A_path = find_file(BASE_DIR, "A_raw", tp, suffix, ".npy")
    B_path = find_file(BASE_DIR, "B",     tp, suffix, ".npy")
    M_path = find_file(BASE_DIR, "mapping_matrix", tp, suffix, ".pt")
    if not (A_path and B_path and M_path):
        print(f"[WARN][{tp}][{model_name}] files missing. Skip.")
        return None

    A_raw = np.load(A_path)                                  # cells × genes
    B_log = np.load(B_path)                                  # spots × genes
    M_t   = torch.load(M_path, map_location="cpu")
    M     = M_t.numpy() if hasattr(M_t, "numpy") else np.asarray(M_t)  # cells × spots

    # 统一口径：M^T @ A_raw → clip>=0 → norm+log1p
    pred_raw = (M.T @ A_raw)                 # spots × genes
    pred_raw = np.clip(pred_raw, 0, None)    # 避免 log1p 负数
    pred     = normalize_log1p_np(pred_raw, TARGET_SUM)
    pred     = np.nan_to_num(pred, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
    true     = np.nan_to_num(B_log, copy=False, nan=0.0, posinf=0.0, neginf=0.0)

    # 方向性余弦相似度分布
    row_sims = cosine_vectors(pred, true, axis=1)  # per-spot
    col_sims = cosine_vectors(pred, true, axis=0)  # per-gene

    # 指标：Global MSE / Global R2 / Mean gene-wise R / Mean spot-wise R（用于 sanity check）
    mse = mean_squared_error(true.ravel(), pred.ravel())
    r2  = r2_score(true.ravel(), pred.ravel())
    gene_r, spot_r = [], []
    for j in range(true.shape[1]):
        rj = safe_corr(true[:, j], pred[:, j])
        if not np.isnan(rj):
            gene_r.append(rj)
    for i in range(true.shape[0]):
        ri = safe_corr(true[i, :], pred[i, :])
        if not np.isnan(ri):
            spot_r.append(ri)

    metrics = {
        "Global MSE": float(mse),
        "Global R2":  float(r2),
        "Mean gene-wise R":  float(np.nanmean(gene_r)) if len(gene_r)>0 else np.nan,
        "Mean spot-wise R":  float(np.nanmean(spot_r)) if len(spot_r)>0 else np.nan,
        "n_spots": true.shape[0],
        "n_genes": true.shape[1],
    }

    return {
        "row_sims": row_sims,
        "col_sims": col_sims,
        "metrics": metrics,
        "pred": pred,
        "true": true,
    }

def select_for_diff(true_mat, pred_mat,
                    gene_topvars=DIFF_GENE_TOPVARS,
                    max_spots=DIFF_MAX_SPOTS):
    """
    为差异热图挑子集：按 true 的列方差选基因前 N；若 spot 太多则等距抽样。
    返回 (true_sub, pred_sub)；均为 [spots' × genes']
    """
    spots, genes = true_mat.shape

    # 基因选择：按 true 的方差从大到小
    if genes > gene_topvars:
        vars_ = true_mat.var(axis=0)
        top_idx = np.argsort(vars_)[::-1][:gene_topvars]
    else:
        top_idx = np.arange(genes)

    true_g  = true_mat[:, top_idx]
    pred_g  = pred_mat[:, top_idx]

    # spot 抽样（如果太多）
    if spots > max_spots:
        idx = np.linspace(0, spots - 1, max_spots).astype(int)
        true_g = true_g[idx, :]
        pred_g = pred_g[idx, :]

    return true_g, pred_g

def plot_diff_heatmap(tp, model_name, true_mat, pred_mat, base_dir=BASE_DIR):
    """
    差异热图：Diff = Pred - True（像表达矩阵那样的热图；不做聚类以提升速度与确定性）
    展示：subset（高方差基因 × 抽样 spots）
    """
    true_sub, pred_sub = select_for_diff(true_mat, pred_mat)
    diff = pred_sub - true_sub

    plt.figure(figsize=DIFF_FIGSIZE)
    ax = sns.heatmap(
        diff, cmap=DIFF_CMAP, center=DIFF_CENTER,
        cbar_kws={'label': 'Pred - True'}
    )
    ax.set_xlabel("Genes (subset)")
    ax.set_ylabel("Spots (subset)")
    ax.set_title(f"Difference Heatmap (Pred - True) @ {tp} [{model_name}]")
    plt.tight_layout()
    out_path = os.path.join(base_dir, f"diff_heatmap_{tp}_{model_name}.png")
    plt.savefig(out_path, dpi=DIFF_DPI, bbox_inches="tight")
    plt.close()
    print(f"[PLOT] {out_path}")

# ========= 主逻辑 =========
def main():
    os.makedirs(BASE_DIR, exist_ok=True)

    for tp in TIMEPOINTS:
        print(f"\n========== Compare at [{tp}] ==========")

        # 收集为 DataFrame：两类 axis（Spot-wise / Gene-wise），每类三个模型
        dfs = []
        per_model_cache = {}  # 保存 pred/true，供后面画差异热图

        for name, suf in MODELS.items():
            res = load_and_predict_for_model(tp, name, suf)
            if res is None:
                continue
            # 方向分布用于箱/小提琴图
            dfs.append(pd.DataFrame({"similarity": res["row_sims"], "axis": "Spot-wise", "model": name}))
            dfs.append(pd.DataFrame({"similarity": res["col_sims"], "axis": "Gene-wise", "model": name}))
            # 缓存矩阵
            per_model_cache[name] = (res["true"], res["pred"])

        if not dfs:
            print(f"[WARN] No model available at {tp}. Skip plots.")
            continue

        df = pd.concat(dfs, ignore_index=True)

        # =============== 1) 箱型图 ===============
        plt.figure(figsize=FIGSIZE_BOX)
        ax = sns.boxplot(
            data=df, x="axis", y="similarity", hue="model",
            palette=PALETTE, showfliers=False
        )
        ax.set_ylim(0, 1.05)
        ax.set_xlabel("")  # 横坐标已是分类名
        ax.set_ylabel("Cosine similarity")
        ax.set_title(f"Cosine similarity (box) across models @ {tp}")
        ax.legend(title="Model", bbox_to_anchor=(1.05, 1), loc='upper left', borderaxespad=0.)
        plt.tight_layout()
        out_box = os.path.join(BASE_DIR, f"compare_box_{tp}.png")
        plt.savefig(out_box, dpi=150, bbox_inches="tight")
        plt.show()
        print(f"[PLOT] {out_box}")

        # =============== 2) 小提琴图 ===============
        plt.figure(figsize=FIGSIZE_VLN)
        ax = sns.violinplot(
            data=df, x="axis", y="similarity", hue="model",
            palette=PALETTE, cut=0, inner="quartile", linewidth=1
        )
        ax.set_ylim(0, 1.05)
        ax.set_xlabel("")
        ax.set_ylabel("Cosine similarity")
        ax.set_title(f"Cosine similarity (violin) across models @ {tp}")
        ax.legend(title="Model", bbox_to_anchor=(1.05, 1), loc='upper left', borderaxespad=0.)
        plt.tight_layout()
        out_violin = os.path.join(BASE_DIR, f"compare_violin_{tp}.png")
        plt.savefig(out_violin, dpi=150, bbox_inches="tight")
        plt.show()
        print(f"[PLOT] {out_violin}")

        # =============== 3) 差异热图（Pred - True） ===============
        for name, (true_mat, pred_mat) in per_model_cache.items():
            plot_diff_heatmap(tp, name, true_mat, pred_mat, base_dir=BASE_DIR)

if __name__ == "__main__":
    main()
