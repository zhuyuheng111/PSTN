# -*- coding: utf-8 -*-
"""
Cell type distribution — True vs PSTN + Difference
Outputs (total 6 figures):
- 3 detailed figures: one per timepoint (0h/12h/24h)
  rows = up to 8 cell types; cols = [True | PSTN | Δ|PSTN−True|]
- 3 summary overlay figures: one per timepoint
  single row; cols = [True | PSTN | Δ]; overlay all 8 cell types in each panel
"""

import os
import numpy as np
import pandas as pd
import scanpy as sc
import torch
import matplotlib.pyplot as plt
import seaborn as sns

# ========= 路径与配置 =========
BASE_DIR    = r"E:\code\deeptalk\selected_HVG4000"
H5AD_DIR    = r"E:\code\deeptalk\selected_HVG4000"
MARKER_FILE = r"E:\code\deeptalk\markerdb_separated_merged.txt"

TIMEPOINTS  = [0, 12, 24]
TARGET_SUM  = 1e4
MAX_MARKERS_PER_TYPE = 3     # 每个类型聚合的 marker 上限
MAX_TYPES_PER_FIG    = 8     # 每张图展示的类型数上限

SAVE_DIR = os.path.join(BASE_DIR, "type_true_pstn_diff_summary6")
os.makedirs(SAVE_DIR, exist_ok=True)

sns.set(style="whitegrid", context="talk")

# —— 显示参数（精细）——
BG_DOT_SIZE   = 2.5     # 背景灰点
FG_DOT_SIZE   = 3.5     # 前景彩色点
ALPHA_MIN     = 0.05    # 透明度下限
ALPHA_MAX     = 0.75    # 透明度上限
THRESH_ALPHA  = 0.10    # True/PSTN 面板中最小显示阈值
THRESH_DIFF   = 0.10    # Δ 面板最小显示阈值
FIG_DPI       = 260

# ========= 工具函数 =========
def normalize_log1p_np(mat, target_sum=1e4):
    mat = np.asarray(mat, dtype=np.float32)
    s = mat.sum(axis=1, keepdims=True)
    s[s == 0] = 1.0
    mat = (mat / s) * target_sum
    return np.log1p(np.clip(mat, 0, None))

def standardize_msu(s: str):
    if s is None or pd.isna(s): return None
    return str(s).strip().replace("LOC-Os", "LOC_Os")

def _candidates(prefix, t, suffix, ext):
    c = [f"{prefix}_{t}{suffix}{ext}"]
    if not str(t).endswith("h"):
        c.append(f"{prefix}_{t}h{suffix}{ext}")
    if str(t).endswith("h"):
        try:
            ti = int(str(t)[:-1]); c.append(f"{prefix}_{ti}h{suffix}{ext}")
        except:
            pass
    return c

def find_file(base_dir, prefix, t, suffix, ext):
    for name in _candidates(prefix, t, suffix, ext):
        p = os.path.join(base_dir, name)
        if os.path.exists(p): return p
    return None

def load_pred_true_for_pstn(t):
    """返回 (pred_pstn, true_Blog)；均为 spots × genes（true 已 log1p）"""
    A_path = find_file(BASE_DIR, "A_raw", t, "", ".npy")
    B_path = find_file(BASE_DIR, "B",     t, "", ".npy")
    M_path = find_file(BASE_DIR, "mapping_matrix", t, "", ".pt")
    if not (A_path and B_path and M_path):
        raise FileNotFoundError(f"Missing files for {t}h in {BASE_DIR}")
    A_raw = np.load(A_path)                         # cells × genes
    B_log = np.load(B_path)                         # spots × genes (log1p)
    M_t   = torch.load(M_path, map_location="cpu")  # cells × spots
    M     = M_t.numpy() if hasattr(M_t, "numpy") else np.asarray(M_t)
    pred_raw = (M.T @ A_raw)                        # spots × genes
    pred     = normalize_log1p_np(np.clip(pred_raw, 0, None), TARGET_SUM)
    return pred, B_log

def pct_norm_01(true_vals, p_lo=1, p_hi=99):
    """用 True 的分位做 0~1 归一（模型共享同一标度）"""
    vmin, vmax = np.percentile(true_vals, [p_lo, p_hi])
    if not np.isfinite(vmin): vmin = 0.0
    if not np.isfinite(vmax) or vmax <= vmin: vmax = vmin + 1e-6
    def scaler(x):
        z = (x - vmin) / (vmax - vmin)
        return np.clip(z, 0.0, 1.0)
    return scaler

def to_alpha(norm01, a_min=ALPHA_MIN, a_max=ALPHA_MAX):
    return a_min + norm01 * (a_max - a_min)

def get_type_palette(types):
    uniq = list(types)
    base = sns.color_palette("tab10", n_colors=max(10, len(uniq)))
    return {tp: base[i % len(base)] for i, tp in enumerate(uniq)}

# ========= 主计算：类型强度（基于 True 的分位归一；模型复用同一标度） =========
def compute_type_scores(varnames_std, B_true, pred_pstn, df_marker,
                        max_markers_per_type=3, max_types=8):
    """
    返回：
      types_sel:   选择展示的类型（最多 max_types）
      markers_per_type: dict[type] -> [genes]
      scores_true: dict[type] -> (n_spots,) ∈ [0,1]
      scores_pstn: dict[type] -> (n_spots,) ∈ [0,1]
    """
    g2idx = {g:i for i,g in enumerate(varnames_std)}
    dfm = df_marker.copy()
    assert {"type","msu"}.issubset(dfm.columns), "marker 表需要列：type, msu"
    dfm["msu_std"] = dfm["msu"].map(standardize_msu)

    # 仅保留在 ST 中存在的 marker
    gset = set(varnames_std)
    dfm = dfm[dfm["msu_std"].notna()]
    dfm = dfm[dfm["msu_std"].astype(str).isin(gset)]
    if dfm.empty:
        return [], {}, {}, {}

    # 以 True 的方差评估类型“信息量”，筛选前 N 个类型
    dfm["var_true"] = dfm["msu_std"].map(lambda g: float(np.var(B_true[:, g2idx[g]])))
    type_strength = (dfm.groupby("type")["var_true"].max()
                     .sort_values(ascending=False).index.tolist())
    types_sel = type_strength[:max_types]

    # per-gene 归一（基于 True）
    scalers = {g: pct_norm_01(B_true[:, g2idx[g]]) for g in dfm["msu_std"].unique()}

    # per-type 强度（True / PSTN）
    scores_true, scores_pstn, markers_per_type = {}, {}, {}
    for tp in types_sel:
        sub = dfm[dfm["type"] == tp].sort_values("var_true", ascending=False)
        genes = sub["msu_std"].tolist()[:max_markers_per_type]
        if not genes:
            continue
        markers_per_type[tp] = genes

        acc_true = 0.0
        acc_pstn = 0.0
        for g in genes:
            j = g2idx[g]
            sc = scalers[g]
            acc_true += sc(B_true[:, j])
            acc_pstn += sc(pred_pstn[:, j])
        scores_true[tp] = (acc_true / len(genes)).astype(np.float32)
        scores_pstn[tp] = (acc_pstn / len(genes)).astype(np.float32)

    # 只保留真正成功计算的类型（防止个别类型没有有效分数）
    types_sel = [tp for tp in types_sel if tp in scores_true and tp in scores_pstn]
    return types_sel, markers_per_type, scores_true, scores_pstn

# ========= 绘图：详细图（每时间点；行=类型；列=True|PSTN|Δ） =========
def plot_timepoint_detail(t, coords, types_sel, scores_true, scores_pstn, out_png):
    n_types = len(types_sel)
    if n_types == 0:
        print(f"[WARN] {t}h: no types to plot."); return

    palette = get_type_palette(types_sel)
    bg_rgba = (0.85, 0.85, 0.85, 0.35)

    fig_w = max(12.0, 3.4 * 3 + 2.0)
    fig_h = 2.6 * n_types + 1.2
    fig, axes = plt.subplots(n_types, 3, figsize=(fig_w, fig_h), constrained_layout=True)
    if n_types == 1:
        axes = np.array([axes])

    for i, tp in enumerate(types_sel):
        true_s  = scores_true[tp]         # 0~1
        pstn_s  = scores_pstn[tp]         # 0~1
        diff_s  = pstn_s - true_s         # 可以为负数

        # 3 列：True / PSTN / Δ
        for j, panel in enumerate(["True", "PSTN", "Δ (PSTN−True)"]):
            ax = axes[i, j]
            ax.scatter(coords[:,0], coords[:,1], s=BG_DOT_SIZE, c=[bg_rgba], linewidths=0, zorder=0)

            if panel == "True":
                vals = true_s
                a = to_alpha(vals)
                mask = a >= THRESH_ALPHA
                if np.any(mask):
                    rgba = np.tile(palette[tp], (mask.sum(), 1))
                    rgba = np.concatenate([rgba, a[mask].reshape(-1,1)], axis=1)
                    ax.scatter(coords[mask,0], coords[mask,1], s=FG_DOT_SIZE, c=rgba, linewidths=0, zorder=1)

            elif panel == "PSTN":
                vals = pstn_s
                a = to_alpha(vals)
                mask = a >= THRESH_ALPHA
                if np.any(mask):
                    rgba = np.tile(palette[tp], (mask.sum(), 1))
                    rgba = np.concatenate([rgba, a[mask].reshape(-1,1)], axis=1)
                    ax.scatter(coords[mask,0], coords[mask,1], s=FG_DOT_SIZE, c=rgba, linewidths=0, zorder=1)

            elif panel.startswith("Δ"):
                vals = diff_s
                a = to_alpha(np.abs(vals))
                mask = a >= THRESH_DIFF
                if np.any(mask):
                    sc = ax.scatter(coords[mask,0], coords[mask,1], s=FG_DOT_SIZE,
                                    c=vals[mask], cmap="bwr", vmin=-1, vmax=1,
                                    alpha=0.9, linewidths=0, zorder=1)
                # 添加 colorbar（只画在最后一行 Δ 面板）
                if i == n_types - 1:
                    fig.colorbar(sc, ax=ax, orientation="horizontal",
                                 fraction=0.06, pad=0.08, label="Δ (PSTN−True)")

            ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")
            if i == 0: ax.set_title(panel, fontsize=12)
            if j == 0: ax.set_ylabel(tp, fontsize=10)

    # 图例放图外右侧（cell types）
    handles = [plt.Line2D([0],[0], marker='o', linestyle='', markersize=6,
                          color=palette[tp], label=tp) for tp in types_sel]
    fig.legend(handles=handles, labels=types_sel,
               title="Cell types", loc="center left", bbox_to_anchor=(1.02, 0.5),
               frameon=True)

    fig.suptitle(f"Cell type distributions — {t}h", fontsize=14)
    fig.savefig(out_png, dpi=FIG_DPI, bbox_inches="tight")
    plt.close(fig)
    print(f"[DETAIL] {out_png}")


# ========= 绘图：汇总图（每时间点；单行叠加 8 types；列=True|PSTN|Δ） =========
def plot_timepoint_summary_overlay(t, coords, types_sel, scores_true, scores_pstn, out_png):
    if len(types_sel) == 0:
        print(f"[WARN] {t}h: no types to plot (summary)."); return

    palette = get_type_palette(types_sel)
    bg_rgba = (0.85, 0.85, 0.85, 0.35)

    fig, axes = plt.subplots(1, 3, figsize=(12, 4.0), constrained_layout=True)
    titles_thr = [("True", THRESH_ALPHA), ("PSTN", THRESH_ALPHA), ("Δ |PSTN−True|", THRESH_DIFF)]

    for c, (panel_title, thr) in enumerate(titles_thr):
        ax = axes[c]
        ax.scatter(coords[:,0], coords[:,1], s=BG_DOT_SIZE, c=[bg_rgba], linewidths=0, zorder=0)
        for tp in types_sel:
            vals = scores_true[tp] if panel_title=="True" else (
                   scores_pstn[tp] if panel_title=="PSTN" else np.abs(scores_pstn[tp]-scores_true[tp]))
            a = to_alpha(vals)
            mask = a >= thr
            if np.any(mask):
                rgba = np.tile(palette[tp], (mask.sum(), 1))
                rgba = np.concatenate([rgba, a[mask].reshape(-1,1)], axis=1)
                ax.scatter(coords[mask,0], coords[mask,1], s=FG_DOT_SIZE, c=rgba, linewidths=0, zorder=1)
        ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")
        ax.set_title(panel_title, fontsize=12)

    # 图外右侧图例（cell types）
    handles = [plt.Line2D([0],[0], marker='o', linestyle='', markersize=6,
                          color=palette[tp], label=tp) for tp in types_sel]
    fig.legend(handles=handles, labels=types_sel,
               title="Cell types", loc="center left", bbox_to_anchor=(1.02, 0.5),
               frameon=True)

    fig.suptitle(f"Summary overlay — {t}h", fontsize=14)
    fig.savefig(out_png, dpi=FIG_DPI, bbox_inches="tight")
    plt.close(fig)
    print(f"[SUMMARY] {out_png}")

# ========= 主流程 =========
if __name__ == "__main__":
    df_marker = pd.read_csv(MARKER_FILE, sep="\t")

    for t in TIMEPOINTS:
        print(f"=== {t}h ===")
        ad = sc.read_h5ad(os.path.join(H5AD_DIR, f"st_{t}h_HVG4000.h5ad"))
        if "spatial" not in ad.obsm:
            raise RuntimeError(f"[{t}h] obsm['spatial'] 不存在")
        coords = np.asarray(ad.obsm["spatial"])
        coords = np.nan_to_num(coords, copy=False)
        varnames_std = np.array([standardize_msu(g) for g in ad.var_names.astype(str)])

        # 载入 True & PSTN
        pred_pstn, B_true = load_pred_true_for_pstn(t)

        # 计算类型强度（基于 True 的分位归一；模型复用同一标度）
        types_sel, markers_per_type, scores_true, scores_pstn = compute_type_scores(
            varnames_std, B_true, pred_pstn, df_marker,
            max_markers_per_type=MAX_MARKERS_PER_TYPE,
            max_types=MAX_TYPES_PER_FIG
        )
        if not types_sel:
            print(f"[WARN] {t}h no types to plot.")
            continue

        # 1) 详细图（行=类型；列=True|PSTN|Δ）
        out_detail = os.path.join(SAVE_DIR, f"type_detail_{t}h.png")
        plot_timepoint_detail(t, coords, types_sel, scores_true, scores_pstn, out_detail)

        # 2) 汇总图（单行叠加 8 types；列=True|PSTN|Δ）
        out_summary = os.path.join(SAVE_DIR, f"type_summary_{t}h.png")
        plot_timepoint_summary_overlay(t, coords, types_sel, scores_true, scores_pstn, out_summary)

    print("Done. 输出目录：", SAVE_DIR)
