# -*- coding: utf-8 -*-
"""
空间模式 8 联图 + HE 原图（使用用户提供的 HE 图片；若不存在再回退到 h5ad）
- 上：8 个基因的预测空间表达（M^T @ A_raw → clip>=0 → normalize_total(1e4)+log1p）
- 下：对应时间点的 HE 原图（不配准、不叠加，仅并排展示）
"""

import os
import re
import numpy as np
import pandas as pd
import scanpy as sc
import torch
import matplotlib.pyplot as plt
import seaborn as sns

# ========= 路径与配置 =========
BASE_DIR    = r"E:\code\deeptalk\selected_HVG4000"  # A_raw/B/M 统一存放
H5AD_DIR    = r"E:\code\deeptalk\selected_HVG4000"  # st_{t}h_HVG4000.h5ad

# 背景 HE 原图（优先使用这些路径）
BG_IMG = {
    0:  r"E:\code\deeptalk\L6_spatial_image.png",     # 0h
    12: r"E:\code\deeptalk\L6_12_spatial_image.png",  # 12h
    24: r"E:\code\deeptalk\L6_24_spatial_image.png",  # 24h
}

# 如需 marker 自动挑选，可提供（可留空不用）
MARKER_FILE = r"E:\code\deeptalk\markerdb_separated_merged.txt"

# 选择时间点与模型
TIMEPOINT = "0h"          # "0h"/"12h"/"24h"
MODEL     = "ours"        # "ours" / "tangram" / "spage"

# 模型显示名称映射
MODEL_LABELS = {
    "ours":    "Our model (fine-tuned)",
    "tangram": "Tangram",
    "spage":   "SpaGE",
}

# 若你想手动指定 8 个基因，填在这里；为空则自动挑
GENE_LIST = []

TARGET_SUM   = 1e4
PANEL_ROWS   = 2
PANEL_COLS   = 4
DOT_SIZE     = 8
ALPHA        = 0.85
CMAP         = "viridis"
VNORM_PCT    = (0, 99)
FIGSIZE_TOP  = (16, 8)    # 8 联图
FIGSIZE_HE   = (16, 8)    # HE 图
DPI          = 200

SUFFIX_MAP = {"ours": "", "tangram": "_tangram", "spage": "_spage"}

sns.set(style="whitegrid", context="talk")

# ========= 工具函数 =========
def normalize_log1p_np(mat, target_sum=1e4):
    mat = np.asarray(mat, dtype=np.float32)
    sums = mat.sum(axis=1, keepdims=True)
    sums[sums == 0] = 1.0
    normed = (mat / sums) * target_sum
    return np.log1p(np.clip(normed, 0, None))

def standardize_msu(s: str):
    if s is None: return None
    s = str(s).strip()
    if not s: return None
    return s.replace("LOC-Os", "LOC_Os")

def _candidates(prefix, tp, suffix, ext):
    cands = [f"{prefix}_{tp}{suffix}{ext}"]
    if not str(tp).endswith("h"):
        cands.append(f"{prefix}_{tp}h{suffix}{ext}")
    if str(tp).endswith("h"):
        try:
            ti = int(str(tp)[:-1])
            cands.append(f"{prefix}_{ti}h{suffix}{ext}")
        except:
            pass
    return cands

def find_file(base_dir, prefix, tp, suffix, ext):
    for name in _candidates(prefix, tp, suffix, ext):
        p = os.path.join(base_dir, name)
        if os.path.exists(p):
            return p
    return None

def load_pred_true(tp, model):
    suffix = SUFFIX_MAP[model]
    A_path = find_file(BASE_DIR, "A_raw", tp, suffix, ".npy")
    B_path = find_file(BASE_DIR, "B",     tp, suffix, ".npy")
    M_path = find_file(BASE_DIR, "mapping_matrix", tp, suffix, ".pt")
    if not (A_path and B_path and M_path):
        raise FileNotFoundError(f"[{model}][{tp}] missing A_raw/B/M in {BASE_DIR}")

    A_raw = np.load(A_path)                         # cells × genes
    B_log = np.load(B_path)                         # spots × genes
    M_t   = torch.load(M_path, map_location="cpu")  # cells × spots
    M     = M_t.numpy() if hasattr(M_t, "numpy") else np.asarray(M_t)

    pred_raw = (M.T @ A_raw)            # spots × genes
    pred_raw = np.clip(pred_raw, 0, None)
    pred     = normalize_log1p_np(pred_raw, TARGET_SUM)
    return pred, B_log

def pick_genes(st_true, varnames_std, marker_file, n=8):
    """按 marker 命中 + ST 方差挑选 n 个基因"""
    if len(varnames_std) == 0:
        return []
    if not marker_file or not os.path.exists(marker_file):
        vars_ = st_true.var(axis=0)
        idx = np.argsort(vars_)[::-1][:n]
        return varnames_std[idx].tolist()

    dfm = pd.read_csv(marker_file, sep="\t")
    if "msu" not in dfm.columns:
        vars_ = st_true.var(axis=0)
        idx = np.argsort(vars_)[::-1][:n]
        return varnames_std[idx].tolist()

    dfm["msu_std"] = dfm["msu"].map(standardize_msu)
    g2idx = {g:i for i,g in enumerate(varnames_std)}
    gene_hit_idx = [g2idx[g] for g in dfm["msu_std"].dropna().astype(str) if g in g2idx]
    gene_hit_idx = np.unique(gene_hit_idx)
    if gene_hit_idx.size == 0:
        vars_ = st_true.var(axis=0)
        idx = np.argsort(vars_)[::-1][:n]
        return varnames_std[idx].tolist()
    vars_sub = st_true.var(axis=0)[gene_hit_idx]
    order = np.argsort(vars_sub)[::-1][:n]
    return [varnames_std[gene_hit_idx[i]] for i in order]

def vmin_vmax(x, pct=(0, 99)):
    lo, hi = np.percentile(x, pct)
    if hi <= lo:
        hi = lo + 1e-6
    return lo, hi

def read_he_image_from_user(timepoint):
    """优先读取用户提供的 HE 图片（BG_IMG）"""
    try:
        ti = int(str(timepoint).replace("h", ""))
    except:
        ti = timepoint
    path = BG_IMG.get(ti, None)
    if path and os.path.exists(path):
        try:
            return plt.imread(path)
        except Exception:
            return None
    return None

def read_he_image_from_adata(ad_st):
    """回退到 Visium 风格的 .uns['spatial']"""
    if "spatial" not in ad_st.uns:
        return None
    spa = ad_st.uns["spatial"]
    if isinstance(spa, dict) and len(spa) > 0:
        lib_id = list(spa.keys())[0]
        images = spa[lib_id].get("images", {})
        for key in ["hires", "lowres"]:
            if key in images:
                return images[key]
    return None

# ========= 主流程 =========
def main():
    # 读 ST（用于坐标和 HE）
    st_path = os.path.join(H5AD_DIR, f"st_{TIMEPOINT}_HVG4000.h5ad")
    ad_st = sc.read_h5ad(st_path)
    if "spatial" not in ad_st.obsm:
        raise RuntimeError("当前 ST 数据中没有 obsm['spatial'] 坐标，无法绘制空间散点。")
    coords = np.asarray(ad_st.obsm["spatial"])
    varnames_raw = np.array(ad_st.var_names.astype(str))
    varnames_std = np.array([standardize_msu(g) for g in varnames_raw])

    # 读 Pred / True
    pred, true = load_pred_true(TIMEPOINT, MODEL)

    # 选择要画的 8 个基因
    if len(GENE_LIST) > 0:
        desired = [standardize_msu(g) for g in GENE_LIST]
        genes = [g for g in desired if g in varnames_std]
    else:
        genes = pick_genes(true, varnames_std, MARKER_FILE, n=PANEL_ROWS*PANEL_COLS)
    if len(genes) == 0:
        raise RuntimeError("没有可用的基因可绘制（基因不在 ST 中）。")

    g2idx = {g:i for i,g in enumerate(varnames_std)}
    gene_idx = [g2idx[g] for g in genes]

    # ---------- 8 联图：pred 的空间散点 ----------
    fig, axes = plt.subplots(PANEL_ROWS, PANEL_COLS, figsize=FIGSIZE_TOP, squeeze=False)
    axes = axes.ravel()
    for k, ax in enumerate(axes):
        if k >= len(gene_idx):
            ax.axis("off")
            continue
        j = gene_idx[k]
        vals = pred[:, j]  # spots
        vmin, vmax = vmin_vmax(vals, VNORM_PCT)
        sc_ = ax.scatter(coords[:,0], coords[:,1], c=vals, s=DOT_SIZE, cmap=CMAP,
                         vmin=vmin, vmax=vmax, alpha=ALPHA, linewidths=0)
        ax.set_title(f"{genes[k]}", fontsize=10)
        ax.set_xticks([]); ax.set_yticks([])
        ax.set_aspect("equal")
        cbar = plt.colorbar(sc_, ax=ax, fraction=0.046, pad=0.02)
        cbar.ax.tick_params(labelsize=8)
    fig.suptitle(f"Spatial patterns (Pred) — {TIMEPOINT} [{MODEL_LABELS[MODEL]}]", y=0.98)
    plt.tight_layout()
    out_png_top = os.path.join(BASE_DIR, f"spatial8_{TIMEPOINT}_{MODEL}.png")
    plt.savefig(out_png_top, dpi=DPI)
    plt.show()
    print(f"[PLOT] {out_png_top}")

    # ---------- HE 原图 ----------
    he_img = read_he_image_from_user(TIMEPOINT)
    if he_img is None:
        he_img = read_he_image_from_adata(ad_st)

    if he_img is not None:
        plt.figure(figsize=FIGSIZE_HE)
        plt.imshow(he_img)
        plt.axis("off")
        plt.title(f"HE image — {TIMEPOINT} [{MODEL_LABELS[MODEL]}]")
        out_png_he = os.path.join(BASE_DIR, f"HE_{TIMEPOINT}.png")
        plt.tight_layout()
        plt.savefig(out_png_he, dpi=DPI)
        plt.show()
        print(f"[PLOT] {out_png_he}")
    else:
        print("[INFO] 未找到 HE 背景图（既无 BG_IMG，也无 uns['spatial']）。")

if __name__ == "__main__":
    main()
